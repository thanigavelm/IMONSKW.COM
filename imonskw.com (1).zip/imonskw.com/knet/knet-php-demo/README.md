# PHP Integration Demo

This is the demo integration kit provided by KNET for PHP.

It provides a sample cart implementation that shows all the components that need
to be implemented for successful validation of your application.

Provided as-is.
